# Resultados

Salidas del simulador generadas con Python 3 y semilla fija. Se pueden regenerar con los mismos comandos y dan los mismos valores.

- `corrida_base/`: una semana de referencia (5/4/3 cajas por franja, fila única).
  `python3 -m supermercado simular --config ejemplos/base.json --semilla 2026 --salida resultados/corrida_base`
  4765 clientes atendidos, espera media 25,05 min, verificación de invariantes ok.

- `comparacion_30/`: seis políticas, 30 semanas cada una (semillas 2026 a 2055), confianza 90 %.
  `python3 -m supermercado experimentar --config ejemplos/base.json --plan comparacion --replicas 30 --semilla 2026 --salida resultados/comparacion_30`
  Mejor política: cinco cajas todo el día, normales (máximo P95 medio 104,17 min, IC 90 % [96,79; 111,54]).
  Ninguna política cumple P95 < 10 min en todas las franjas de alguna semana.
